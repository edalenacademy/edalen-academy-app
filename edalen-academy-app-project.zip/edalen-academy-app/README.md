# Edalen Academy Android App

A WebView Android wrapper for the Edalen Academy website.

Website: https://edalenacademy.github.io/edalenacademy/#/login

## Build
Open GitHub Actions and run **Build Edalen Academy APK**. Download the
`edalen-academy-debug-apk` artifact after the workflow completes.
